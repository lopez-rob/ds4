﻿using System;

namespace Laboratorio21
{
    public class Program
    {
        public static void Main()
        {
            //asignando valor a variable estatica
            MyClass.Valor = 1;
            Console.WriteLine(MyClass.Valor);
        }
    }
    public class MyClass
    {
        //declatrando variable estatica
        public static int Valor;

    }
}