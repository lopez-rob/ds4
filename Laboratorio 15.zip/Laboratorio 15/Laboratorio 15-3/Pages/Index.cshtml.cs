﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public string? UserInput { get; set; }

        public string? Message { get; set; }

        public void OnPost()
        {
            // Asignar el mensaje introducido por el usuario
            Message = UserInput;
        }
    }
}
