﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public int Numero1 { get; set; }

        [BindProperty]
        public int Numero2 { get; set; }

        public int? Resultado { get; set; }

        public void OnPost()
        {
            // Realizar la suma
            Resultado = Numero1 + Numero2;
        }
    }
}
