namespace Laboratorio12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Por favor, ingresa valores en ambos campos.");
                return;
            }

            try
            {
                double velocidad = double.Parse(textBox1.Text);
                double tiempo = double.Parse(textBox2.Text);
                double distancia = velocidad * tiempo;
                textBox3.Text = distancia.ToString();
            }
            catch
            {
                MessageBox.Show("Por favor, ingresa valores v�lidos.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_click(object sender, EventArgs e)
        {

        }
    }
}
