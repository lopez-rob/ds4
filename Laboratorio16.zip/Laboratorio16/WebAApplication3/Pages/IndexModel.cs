﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebAApplication3.Pages
{
    public class IndexModel : PageModel
    {
        // Propiedad pública para el mensaje
        public string Mensaje { get; set; } = string.Empty;

        // Método para manejar la carga de la página
        public void OnGet()
        {
            // Inicializa el mensaje al cargar la página
            Mensaje = "¡Bienvenido a Razor Pages!";
        }
    }
}
